let logo = document.getElementById("hplogo");
logo.src = 'https://cdn.pixabay.com/photo/2013/01/29/22/53/yahoo-76684_960_720.png';
logo.srcset = '';
let search = document.getElementsByClassName('gNO89b')[1];
search.value = 'Yahoo!';
